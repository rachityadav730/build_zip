#usage z.b:  export remote_host=192.168.178.49  ;  export system_id=dddexa ;  cap deploy:cold
# http://www.andrewbruce.net/code/capistrano_sftp_deployment

system_id=ENV["system_id"]
unless system_id
  puts "no system_id given. exit."
  exit(-1)
end

ssh_options[:port] = ENV["remote_port"] if ENV["remote_host"]!=nil and ENV["remote_host"]!=""

my_host=ENV["remote_host"]
local=my_host.nil?
my_host="localhost" if local

############################################################
#	Application
#############################################################

set :application, "wdoku"
set :deploy_to, "/var/www/wdoku"

#############################################################
#	Settings
#############################################################

default_run_options[:pty] = true
set :use_sudo, false
set :keep_releases, 8 #Wird nicht per se gelöscht, nur bei "cap deploy:cleanup"
set :cleanup_via, :run #don't use sudo

#############################################################
#	Servers
#############################################################

set :user, "wdoku"
set :domain, "wdoku"
server my_host, :app, :web
role :db, my_host, :primary => true

puts "my_host=#{my_host}"
#############################################################
#	Subversion
#############################################################

set :debug, true
set :repository,  "http://192.168.233.29/wdoku/trunk"
set :checkout, "export"
unless local
  set :deploy_via, :copy
  set :copy_strategy, :export
  excludes=["**/.git", "**/.svn", ".git", ".svn"]
  clinic_names=Dir["data/clinics/*"].map{|name|name.gsub("data/clinics/","")}
  clinic_names.delete(system_id)
  clinic_names.each do |name|
    excludes<<"data/clinics/#{name}"
    excludes<<"lib/clinics/#{name}"
    excludes<<"data/clinics/#{name}/*"
    excludes<<"lib/clinics/#{name}/*"
  end
  puts "excludes=#{excludes.inspect}"
  set :copy_exclude, excludes
  set :copy_compression, :zip
  set :copy_cache, "/tmp/.wdoku_export_cache/"
end

#############################################################
#	Passenger
#############################################################

namespace :passenger do
  desc "Restart Application"
  task :restart do
    run "touch #{current_path}/tmp/restart.txt"
  end
end

after :deploy, "passenger:restart"

task :after_update_code do
  run "cp ~/wdoku_database_production.yml #{release_path}/config/database.yml"
  run "mkdir -p #{shared_path}/incoming"
  run "ln -s #{shared_path}/incoming #{latest_release}/incoming"

end
