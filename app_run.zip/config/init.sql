CREATE DATABASE IF NOT EXISTS wdoku_addemo_development;
CREATE DATABASE IF NOT EXISTS wdoku_addemo_test;
CREATE DATABASE IF NOT EXISTS wdoku_addemo_production;

CREATE USER 'wdoku'@'%' IDENTIFIED BY 'wdoku';
GRANT ALL PRIVILEGES ON wdoku.* TO 'wdoku'@'%' WITH GRANT OPTION;
GRANT SUPER, SYSTEM_VARIABLES_ADMIN ON *.* TO 'wdoku'@'%';
GRANT ALL PRIVILEGES ON wdoku_addemo_development.* TO 'wdoku'@'%';
GRANT ALL PRIVILEGES ON wdoku_addemo_test.* TO 'wdoku'@'%';
GRANT ALL PRIVILEGES ON wdoku_addemo_production.* TO 'wdoku'@'%';
FLUSH PRIVILEGES;